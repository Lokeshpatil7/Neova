package com.example.demo;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Employee;
import com.example.demo.layer3.EmployeeRepositoryImpl;

@SpringBootTest
public class SpringOrmApplicationEmpTests
{
	@Autowired
	EmployeeRepositoryImpl empRepo;
	
	/*@Test
	void insertEmpTest()
	{
		LocalDate ld=LocalDate.of(2021, 10, 13);
		Employee emp=new Employee();
		
		emp.setEmployeeNo(4201);
		emp.setEmployeeName("Lokesh");
		emp.setEmployeeJob("Developer");
		emp.setEmployeeMgr(7934);
		emp.setEmployeeHiredate(ld);
		emp.setEmployeeSalary(2500);
		emp.setEmployeeComm(00);
	//	emp.setEmployeeDeptno(10);
		
		empRepo.insertEmployee(emp);
	}
	*/
	/*@Test
	void selectEmpTest()
	{
		Employee emp;
		emp=empRepo.selectEmployee();
		System.out.println("emp no: "+emp.getEmployeeNo());
		System.out.println("emp name: "+emp.getEmployeeName());
		System.out.println("emp job:  "+emp.getEmployeeJob());
		System.out.println("emp mgr: "+emp.getEmployeeMgr());
		System.out.println("emp hiredate: "+emp.getEmployeeHiredate());
		System.out.println("emp sal: "+emp.getEmployeeSalary());
		System.out.println("emp comm: "+emp.getEmployeeComm());
	//	System.out.println("emp dept no: "+emp.getEmployeeDeptno());
	} */
	
	@Test
	void updateEmpTest()
	{
		LocalDate ld=LocalDate.of(2021, 10, 13);

		Employee emp=new Employee();
		
		emp.setEmployeeNo(4201);
		emp.setEmployeeName("Patil");
		emp.setEmployeeJob("Developer");
		emp.setEmployeeMgr(7934);
		emp.setEmployeeHiredate(ld);
		emp.setEmployeeSalary(2500);
		emp.setEmployeeComm(001);
	//	emp.setEmployeeDeptno(10);
		
		empRepo.updateEmployee(emp);
	}
	
	
	/*
	@Test
	void deleteDeptTest()
	{
		 
		empRepo.selectEmployee(7934);
		
	}
	*/
	
	
	
	/*
	@Test
	void selectAllEmpTest()
	{
		List<Employee> empList;
		empList=empRepo.selectEmployees();
		for(Employee emp : empList)
		{
			System.out.println("emp no: "+emp.getEmployeeNo());
			System.out.println("emp name: "+emp.getEmployeeName());
			System.out.println("emp job:  "+emp.getEmployeeJob());
			System.out.println("emp mgr: "+emp.getEmployeeMgr());
			System.out.println("emp hiredate: "+emp.getEmployeeHiredate());
			System.out.println("emp sal: "+emp.getEmployeeSalary());
			System.out.println("emp comm: "+emp.getEmployeeComm());
			//System.out.println("emp dept no: "+emp.getEmployeeDeptno());

		}
	}
	*/
	
	
}