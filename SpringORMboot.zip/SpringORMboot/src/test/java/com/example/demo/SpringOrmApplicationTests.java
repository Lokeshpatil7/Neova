package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Department;
import com.example.demo.layer3.DepartmentRepositoryImpl;

@SpringBootTest
class SpringOrmApplicationTests {
	
	@Autowired
	DepartmentRepositoryImpl deptRepo;

//	@Test
//	void insertDeptTest() {
//		Department dept = new Department();
//		dept.setDepartmentNumber();
//		dept.setDepartmentName("Sa");
//		dept.setDepartmentLocation("MI");
//		
//		deptRepo.insertDepartment(dept);
//	}
//	
//	@Test
//	void updateDeptTest() {
//		Department dept = new Department();
//		dept.setDepartmentNumber(1);
//		dept.setDepartmentName("yush");
//		dept.setDepartmentLocation("MeciucI");
//		
//		deptRepo.updateDepartment(dept);
//	}
	
	@Test
	void deleteDeptTest() {
		deptRepo.deleteDepartment(2);
	}


}
