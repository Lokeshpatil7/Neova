package com.example.demo.layer2;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="emp6")
public class Employee {
	
	@Id
	@Column(name="empno")
	private int employeeNo;
	
	@Column(name="ename")
	private String employeeName;
	
	@Column(name="job")
	private String employeeJob;
	
	@Column(name="mgr")
	private int employeeMgr;
	
	@Column(name="hiredate")
	private LocalDate employeeHiredate; //date
	
	@Column(name="sal")
	private int employeeSalary;
	
	@Column(name="comm")
	private int employeeComm;
	
	
    
/*	@Column(name="deptno")
	public int getEmployeeNo() {
		return employeeNo;
	}
*/
	public void setEmployeeNo(int employeeNo) {
		this.employeeNo = employeeNo;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeJob() {
		return employeeJob;
	}

	public void setEmployeeJob(String employeeJob) {
		this.employeeJob = employeeJob;
	}

	public int getEmployeeMgr() {
		return employeeMgr;
	}

	public void setEmployeeMgr(int employeeMgr) {
		this.employeeMgr = employeeMgr;
	}

	public LocalDate getEmployeeHiredate() {
		return employeeHiredate;
	}

	public void setEmployeeHiredate(LocalDate employeeHiredate) {
		this.employeeHiredate = employeeHiredate;
	}

	public int getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(int employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public int getEmployeeComm() {
		return employeeComm;
	}

	public void setEmployeeComm(int employeeComm) {
		this.employeeComm = employeeComm;
	}

	/*public int getEmployeeDeptno() {
		return employeeDeptno;
	}

	public void setEmployeeDeptno(int employeeDeptno) {
		this.employeeDeptno = employeeDeptno;
	}
	
	*/
	

}
